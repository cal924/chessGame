package chessgame;

public abstract class ChessGame {
	
	public static final int defChessBoardSize = 16;
	
	public static final char player1 = 'B';
	public static final char player2 = 'W';
	public static final char empty = 'X';
	
	protected char[][] chessBoard;
	
	/**
	 * Initialize the chess board using default size
	 */
	public ChessGame(){
		this(defChessBoardSize);
	}
	
	public ChessGame(int size){
		initializeChessBoard(size);
	}
	
	/**
	 * Initialize the chess board
	 * @param size the width/ height of the ChessBoard
	 */
	public void initializeChessBoard(int size){
		//TODO create a 2D array. Set all grids to default value
		chessBoard = new char[size][size];
		for (int i = 0 ; i < size ; i++){
			for (int j = 0 ; j < size ; j++){
				chessBoard[i][j] = empty;
			}
		}
	}
	
	/**
	 * @return width
	 */
	public int getChessBoardWidth(){
		return chessBoard.length;
	}
	
	/**
	 * @return height
	 */
	public int getChessBoardHeight(){
		return chessBoard[0].length;
	}
	
	/**
	 * Print out the chessboard
	 */
	public void showChessBoard(){
		//TODO implement your code to show the chess board
		for (int i = 0 ; i < getChessBoardWidth() ; i++){
			for (int j = 0 ; j < getChessBoardHeight() ; j++){
				System.out.print(chessBoard[i][j] + " ");
			}
			System.out.println("");
		}
	}
	
	/**
	 * return if a coordinate is available
	 * @param c coordinate
	 * @return true - available
	 */
	public boolean isLocationAvailable(Coordinate c){
		//TODO check if a particular location is available to put a chess
		return true;
	}
	
	/**
	 * Put a chess
	 * @param c coordinate
	 * @param playerColor the user color ('B' or 'W')
	 * @return true - success
	 */
	public boolean putChess(Coordinate c, char playerColor){
		//TODO add a chess to the chessBoard;
		//TODO return true if the chess can be put successfully. 
		return true;
	}
	
	/**
	 * Return whether the game result is settled and the input player has won the game 
	 * @param playerColor
	 * @return
	 */
	public abstract boolean isPlayerWon(char playerColor);
		//TODO return if a player won
		//1. Check any horizontal five chess in a row
		//2. Check any vertical five chess in a col
		//3. Chek any diagonal line
	
	/**
	 * If chessboard is full, i.e. no more available space
	 * @return true - already full; false - still have space
	 */
	public boolean isChessBoardFull(){
		//TODO return if a chess board is already full;
		return false;
	}
	
	/**
	 * Get the next player
	 * @return playerColor..maybe 'B' or 'W'
	 */
	public char getNextPlayer(){
		if (isChessBoardFull()){
			return empty;	//The game is over;
		}
		
		int player1Count = 0;
		int player2Count = 0;
		
		for (int i = 0 ; i < chessBoard.length ; i++){
			for(int j = 0 ; j < chessBoard[0].length ; j++){
				switch (chessBoard[i][j]){
				case player1 : player1Count++;break;
				case player2 : player2Count++;break;
				default: break;
				}
			}
		}
		
		//Since player 1 start first, only two cases
		//Case 1, player1Count = player2Count + 1  -> player2's turn
		//Case 2, player1Count = player2Count -> player1's turn
		return player1Count > player2Count ? player2 : player1;
	}
	
	/**
	 * it is a valid coordinate in the chessboard
	 * @param c coordinate
	 */
	public boolean isValidCoordinate(Coordinate c){
		return c.getX() >= 0 && c.getX() < chessBoard.length
				&& c.getY() >= 0 && c.getY() < chessBoard.length;
	}
	
	/**
	 * the game is finished
	 * @return either someone won, or the game is drawn and no more steps can be made
	 */
	public boolean isGameDone(){
		return isPlayerWon(player1) || isPlayerWon(player2) || isChessBoardFull();
	}
}
