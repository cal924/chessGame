package chessgame.reversi;

import chessgame.ChessGame;
import chessgame.Coordinate;

public class Reversi extends ChessGame {

	private char nextPlayer = empty;
	
	@Override
	public void initializeChessBoard(int size){
		super.initializeChessBoard(size);
		//TODO add the four chess at the middle;
		nextPlayer = player1;
	}
	
	@Override
	public boolean putChess(Coordinate c, char playerColor) {
		//TODO call super to put the chess
		//TODO do the flips
		//TODO 1. Check all the eight directions if it is a series of anotherPlayerColor and then a same color chess
		//  (Probably need to write eight times...or u can think of a really smart 2D for loop)
		updateNextPlayer(playerColor);
		return false;
	}

	@Override
	public boolean isPlayerWon(char playerColor) {
		// TODO ChessBoard full + get more chess than other
		return false;
	}
	
	public void updateNextPlayer(char lastPlayerColor){
		nextPlayer = lastPlayerColor == player1 ? player2 : player1;
		
		if (isPlayerHaveLocation(nextPlayer)){
			return;
		}else if (isPlayerHaveLocation(lastPlayerColor)){
			nextPlayer = lastPlayerColor;
		}else{
			nextPlayer = empty;
		}
	}
	
	private boolean isPlayerHaveLocation(char playerColor){
		//TODO write a loop to search if any grid is empty and can put playerX's chess (i.e. can lead to flip)
		//TODO make use of isLocationAvailableForPlayer
		return true;
	}
	
	public boolean isLocationAvailableForPlayer(Coordinate c, char playerColor){
		if (!isLocationAvailable(c)){
			return false;
		}
		//TODO check if this location can lead to flips
		return true;
	}

	@Override
	public boolean isGameDone(){
		//TODO return true when no more space for user to flip
		return true;
	}
	
	@Override
	public char getNextPlayer(){
		return nextPlayer;
	}
}
