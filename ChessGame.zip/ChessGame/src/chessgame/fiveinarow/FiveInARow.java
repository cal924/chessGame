package chessgame.fiveinarow;

import chessgame.ChessGame;
import chessgame.Coordinate;

public class FiveInARow extends ChessGame {

	@Override
	public boolean putChess(Coordinate c, char playerColor) {
		// TODO Fill me in
		return true;
	}

	@Override
	public boolean isPlayerWon(char playerColor) {
		// TODO return someoneGotAFiveInRow
		//1. Check diagonal
		//1.1 Check diagonal \
		for (int i = 0 ; i < getChessBoardWidth() - 4 ; i++){
			for (int j = 0 ; j < getChessBoardHeight() - 4 ; j++){
				if (chessBoard[i][j] != playerColor){
					continue;
				}
				char chess1 = chessBoard[i][j];
				char chess2 = chessBoard[i+1][j+1];
				char chess3 = chessBoard[i+2][j+2];
				char chess4 = chessBoard[i+3][j+3];
				char chess5 = chessBoard[i+4][j+4];
				
				boolean inARow = (chess1 == chess2) && (chess2 == chess3);//etc
				if(inARow){
					return true;
				}
			}
		}
		//TODO 1.2 Check diagonal /
		//TODO 2. CHeck horizontal
		//TODO 3, Check vertical
		return false;
	}
}
